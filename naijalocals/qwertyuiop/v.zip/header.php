<!DOCTYPE html>
<html>
    <head>
        <link href="ad.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <header>
            <h1>ADMIN DASHBOARD</h1>
            <nav><ul>
                <li><a href="create_article.php">NEW ARTICLE</a></li>
                <li><a href="create_musics.php">NEW MUSICS</a></li>
                <li><a href="create_videos.php">NEW VIDEOS</a></li>
            </ul></nav>
            <nav><ul>
                <li><a href="edit_article.php">EDIT ARTICLE</a></li>
                <li><a href="edit_musics.php">EDIT MUSICS</a></li>
                <li><a href="edit_videos.php">EDIT VIDEOS</a></li>
            </ul></nav>
            <nav><ul>
                <li><a href="manage_subject.php">MANAGE SUBJECT</a></li>
                <li><a href="manage_users.php">MANAGE USERS</a></li>
                <li><a href="manage_admin.php">MANAGE ADMIN</a></li>
            </ul></nav>
            <nav><ul>
                <li><a href="about_us.php">About us</a></li>
                <li><a href="file_upload_manager.php">file manager</a></li>
                <li><a href="file_ref.php">file ref</a></li>
            </ul></nav>
        </header>
        <section>
   
